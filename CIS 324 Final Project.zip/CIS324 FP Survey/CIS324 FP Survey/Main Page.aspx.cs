﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CIS324_FP_Survey
{
    public partial class Main_Page : System.Web.UI.Page
    {
        int count1, count2, count3, count4;

        

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Session["FirstName"] = txtbxFirstName.Text;
            Session["LastName"] = txtbxLastName.Text;
            GetAnswers();
            if(count1 > count2 && count1 > count3 && count1 > count4)
            {
                Response.Redirect("Life of the Party.aspx");
            }
            else if (count2 > count1 && count2 > count3 && count2 > count4)
            {
                Response.Redirect("Homebody.aspx");
            }
            else if (count3 > count1 && count3 > count2 && count3 > count4)
            {
                Response.Redirect("Romantically-Inclined.aspx");
            }
            else if (count4 > count1 && count4 > count2 && count4 > count3)
            {
                Response.Redirect("Family Affair.aspx");
            }
        }

        private void GetAnswers()
        {
           

            string selectedvalue = rbList1.SelectedValue;

            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }
             selectedvalue = rbList2.SelectedValue;
            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }

            selectedvalue = rbList3.SelectedValue;
            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }

            selectedvalue = rbList4.SelectedValue;
            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }


            selectedvalue = rbList5.SelectedValue;
            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }

            selectedvalue = rbList6.SelectedValue;
            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }

            selectedvalue = rbList7.SelectedValue;
            switch (selectedvalue)
            {
                case "A":
                    count1++;
                    break;
                case "B":
                    count2++;
                    break;
                case "C":
                    count3++;
                    break;
                case "D":
                    count4++;
                    break;
                default:
                    break;

            }


        }

  

        protected void Page_Load(object sender, EventArgs e)
        {

        }

    }
}